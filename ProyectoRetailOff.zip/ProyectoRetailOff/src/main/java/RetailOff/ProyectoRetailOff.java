package RetailOff;

public class ProyectoRetailOff {

	public static void main(String[] args) {
		
		
		System.out.println("Bienvenidoo al Proyecto RetailOff"); 
		
	}

}
